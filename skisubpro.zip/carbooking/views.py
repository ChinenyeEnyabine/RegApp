from django.shortcuts import render
from rest_framework import viewsets,permissions
from .models import Car, Booking, CarMake, CarModel
from .serializers import CarSerializer, BookingSerializer, CarmakeSerializer, CarmodelSerializer
from rest_framework.permissions import IsAuthenticated
class CarMakeViewSet(viewsets.ModelViewSet):
    queryset = CarMake.objects.all()
    serializer_class = CarmakeSerializer

class CarModelViewSet(viewsets.ModelViewSet):
    queryset = CarModel.objects.all()
    serializer_class = CarmodelSerializer

class CarViewSet(viewsets.ModelViewSet):
    queryset = Car.objects.all()
    serializer_class = CarSerializer

class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer
    # permission_classes = [IsAuthenticated]

